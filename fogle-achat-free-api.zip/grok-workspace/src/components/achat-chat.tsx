import { useEffect, useRef, useState } from "react";
import { ArrowUp, Plus, Square } from "lucide-react";
import { AchatMark } from "@/components/achat-mark";
import { MarkdownLite } from "@/components/markdown-lite";
import { streamAchat, type ClientMessage } from "@/lib/achat-client";
import { cn } from "@/lib/utils";

type UiMessage = ClientMessage & { id: string };

const SUGGESTIONS = [
  "Me explique o Fogle em uma frase",
  "Como fazer um bolo de chocolate simples",
  "O que está acontecendo na ciência esta semana?",
  "Planeje um fim de semana em São Paulo",
];

const autoStarted = new Set<string>();

function uid() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

export function AchatChat({
  initialQuery = "",
  lucky = false,
}: {
  initialQuery?: string;
  lucky?: boolean;
}) {
  const [messages, setMessages] = useState<UiMessage[]>([]);
  const [draft, setDraft] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: "end" });
  }, [messages, busy]);

  async function send(text: string, history?: UiMessage[]) {
    const content = text.trim();
    if (!content || busy) return;

    const prior = history ?? messages;
    const user: UiMessage = { id: uid(), role: "user", content };
    const assistantId = uid();
    const next = [...prior, user];
    setMessages([...next, { id: assistantId, role: "assistant", content: "" }]);
    setDraft("");
    setBusy(true);
    setError(null);

    const controller = new AbortController();
    abortRef.current = controller;

    try {
      await streamAchat(
        next.map(({ role, content: c }) => ({ role, content: c })),
        (delta) => {
          setMessages((curr) =>
            curr.map((m) => (m.id === assistantId ? { ...m, content: m.content + delta } : m)),
          );
        },
        controller.signal,
      );
    } catch (err) {
      if ((err as Error).name === "AbortError") return;
      const message = err instanceof Error ? err.message : "Achat indisponível.";
      setError(message);
      setMessages((curr) =>
        curr.map((m) =>
          m.id === assistantId
            ? { ...m, content: m.content || "Não consegui responder agora. Tente de novo." }
            : m,
        ),
      );
    } finally {
      setBusy(false);
      abortRef.current = null;
    }
  }

  useEffect(() => {
    const q = initialQuery.trim();
    if (!q) return;
    if (autoStarted.has(q)) return;
    autoStarted.add(q);
    void send(q, []);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialQuery]);

  function stop() {
    abortRef.current?.abort();
    setBusy(false);
  }

  function reset() {
    abortRef.current?.abort();
    setMessages([]);
    setDraft("");
    setBusy(false);
    setError(null);
  }

  const empty = messages.length === 0 && !busy;

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="min-h-0 flex-1 overflow-y-auto">
        <div className="mx-auto w-full max-w-results px-4 py-8">
          {lucky && empty ? (
            <p className="mb-6 text-center text-sm text-muted">Você está com sorte</p>
          ) : null}

          {empty ? (
            <div className="flex flex-col items-center pt-6 text-center sm:pt-10">
              <span className="grid size-14 place-items-center rounded-full bg-accent-soft text-accent">
                <AchatMark className="size-7" />
              </span>
              <h1 className="mt-5 font-display text-3xl font-semibold tracking-tight">
                Olá. Eu sou o Achat.
              </h1>
              <p className="mt-2 max-w-md text-muted">
                A inteligência do Fogle, direto na pesquisa. Pergunte qualquer coisa.
              </p>
              <ul className="mt-8 grid w-full gap-2 sm:grid-cols-2">
                {SUGGESTIONS.map((item) => (
                  <li key={item}>
                    <button
                      type="button"
                      onClick={() => void send(item)}
                      className="press w-full rounded-lg border border-border bg-bg px-4 py-3 text-left text-sm text-fg hover:bg-surface"
                    >
                      {item}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ) : (
            <ol className="space-y-6">
              {messages.map((m) => (
                <li key={m.id} className={cn("flex", m.role === "user" ? "justify-end" : "justify-start")}>
                  {m.role === "user" ? (
                    <div className="max-w-md rounded-xl rounded-br-xs bg-surface-2 px-4 py-3 text-fg">
                      {m.content}
                    </div>
                  ) : (
                    <div className="flex max-w-full gap-3">
                      <span className="mt-1 grid size-8 shrink-0 place-items-center rounded-full bg-accent-soft text-accent">
                        <AchatMark className="size-3.5" />
                      </span>
                      <div className="min-w-0 flex-1 pt-1">
                        {m.content ? (
                          <MarkdownLite text={m.content} />
                        ) : (
                          <span className="typing-dots inline-flex gap-1 pt-2" aria-label="Achat está escrevendo">
                            <span className="size-1.5 rounded-full bg-muted" />
                            <span className="size-1.5 rounded-full bg-muted" />
                            <span className="size-1.5 rounded-full bg-muted" />
                          </span>
                        )}
                      </div>
                    </div>
                  )}
                </li>
              ))}
            </ol>
          )}
          {error ? <p className="mt-4 text-sm text-danger">{error}</p> : null}
          <div ref={endRef} />
        </div>
      </div>

      <div className="border-t border-border bg-bg px-3 py-3 sm:px-4">
        <form
          className="mx-auto flex w-full max-w-results items-end gap-2 rounded-xl border border-border-strong bg-bg px-3 py-2 shadow-search"
          onSubmit={(e) => {
            e.preventDefault();
            void send(draft);
          }}
        >
          <button
            type="button"
            onClick={reset}
            aria-label="Nova conversa"
            className="press mb-0.5 grid size-10 shrink-0 place-items-center rounded-full text-muted hover:bg-surface hover:text-fg"
          >
            <Plus className="size-5" />
          </button>
          <label htmlFor="achat-draft" className="sr-only">
            Mensagem para o Achat
          </label>
          <textarea
            id="achat-draft"
            rows={1}
            value={draft}
            placeholder="Pergunte ao Achat"
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                void send(draft);
              }
            }}
            className="max-h-36 min-h-11 flex-1 resize-none bg-transparent py-2.5 text-base text-fg outline-none placeholder:text-subtle"
          />
          {busy ? (
            <button
              type="button"
              onClick={stop}
              aria-label="Parar"
              className="press mb-0.5 grid size-10 shrink-0 place-items-center rounded-full bg-fg text-bg"
            >
              <Square className="size-3.5 fill-current" />
            </button>
          ) : (
            <button
              type="submit"
              disabled={!draft.trim()}
              aria-label="Enviar"
              className="press mb-0.5 grid size-10 shrink-0 place-items-center rounded-full bg-accent text-accent-fg disabled:bg-surface-2 disabled:text-subtle"
            >
              <ArrowUp className="size-5" />
            </button>
          )}
        </form>
        <p className="mx-auto mt-2 max-w-results px-2 text-center text-xs text-subtle">
          O Achat pode errar. Confira informações importantes.
        </p>
      </div>
    </div>
  );
}
