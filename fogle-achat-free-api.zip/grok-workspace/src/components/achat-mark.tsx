import { cn } from "@/lib/utils";

export function AchatMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      aria-hidden="true"
      className={cn("size-5 shrink-0", className)}
    >
      <path
        d="M12 2.2 13.55 9.4 21 12 13.55 14.6 12 21.8 10.45 14.6 3 12 10.45 9.4Z"
        fill="currentColor"
      />
    </svg>
  );
}
