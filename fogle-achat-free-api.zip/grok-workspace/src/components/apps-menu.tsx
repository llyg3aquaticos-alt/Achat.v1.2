import { useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { Grid3x3, Info, MessageCircle, Search, Shuffle } from "lucide-react";
import { AchatMark } from "@/components/achat-mark";
import { pickLuckyQuery } from "@/lib/lucky";
import { cn } from "@/lib/utils";

export function AppsMenu() {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  return (
    <div className="relative">
      <button
        type="button"
        aria-haspopup="menu"
        aria-expanded={open}
        aria-label="Apps do Fogle"
        onClick={() => setOpen((v) => !v)}
        className="press grid size-11 place-items-center rounded-full text-muted hover:bg-surface"
      >
        <Grid3x3 className="size-5" strokeWidth={1.75} />
      </button>
      {open ? (
        <>
          <button
            type="button"
            aria-label="Fechar menu"
            className="fixed inset-0 z-30 cursor-default"
            onClick={() => setOpen(false)}
          />
          <div
            role="menu"
            className="absolute right-0 z-40 mt-1 w-72 rounded-xl border border-border bg-bg p-4 shadow-menu"
          >
            <p className="px-1 pb-3 text-xs font-medium uppercase tracking-wide text-subtle">
              Apps Fogle
            </p>
            <div className="grid grid-cols-3 gap-1">
              <Link
                to="/"
                role="menuitem"
                onClick={() => setOpen(false)}
                className="flex flex-col items-center gap-2 rounded-md px-2 py-3 text-sm text-fg hover:bg-surface"
              >
                <span className="grid size-10 place-items-center rounded-lg bg-surface text-accent">
                  <Search className="size-5" />
                </span>
                Pesquisa
              </Link>
              <Link
                to="/achat"
                role="menuitem"
                onClick={() => setOpen(false)}
                className="flex flex-col items-center gap-2 rounded-md px-2 py-3 text-sm text-fg hover:bg-surface"
              >
                <span className="grid size-10 place-items-center rounded-lg bg-accent-soft text-accent">
                  <AchatMark className="size-5" />
                </span>
                Achat
              </Link>
              <Link
                to="/sobre"
                role="menuitem"
                onClick={() => setOpen(false)}
                className="flex flex-col items-center gap-2 rounded-md px-2 py-3 text-sm text-fg hover:bg-surface"
              >
                <span className="grid size-10 place-items-center rounded-lg bg-surface text-accent">
                  <Info className="size-5" />
                </span>
                Sobre
              </Link>
              <Link
                to="/achat"
                search={{ q: "Olá, Achat" }}
                role="menuitem"
                onClick={() => setOpen(false)}
                className="flex flex-col items-center gap-2 rounded-md px-2 py-3 text-sm text-fg hover:bg-surface"
              >
                <span className="grid size-10 place-items-center rounded-lg bg-surface text-accent">
                  <MessageCircle className="size-5" />
                </span>
                Conversar
              </Link>
              <button
                type="button"
                role="menuitem"
                onClick={() => {
                  setOpen(false);
                  void navigate({
                    to: "/achat",
                    search: { q: pickLuckyQuery(), lucky: "1" },
                  });
                }}
                className="flex flex-col items-center gap-2 rounded-md px-2 py-3 text-sm text-fg hover:bg-surface"
              >
                <span className="grid size-10 place-items-center rounded-lg bg-surface text-fogle-green">
                  <Shuffle className="size-5" />
                </span>
                Sorte
              </button>
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
}

export function HeaderAvatar() {
  return (
    <Link
      to="/achat"
      aria-label="Abrir o Achat"
      className={cn(
        "press grid size-9 place-items-center rounded-full bg-accent text-sm font-semibold text-accent-fg",
        "shadow-search",
      )}
    >
      A
    </Link>
  );
}
