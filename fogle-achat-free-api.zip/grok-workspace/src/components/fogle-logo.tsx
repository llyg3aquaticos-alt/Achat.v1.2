import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";

type Size = "sm" | "md" | "lg";

const sizeClass: Record<Size, string> = {
  sm: "text-2xl leading-none",
  md: "text-4xl leading-none",
  lg: "text-logo leading-none",
};

export function FogleWordmark({
  size = "lg",
  className,
}: {
  size?: Size;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "font-display font-semibold tracking-logo select-none",
        sizeClass[size],
        className,
      )}
      aria-label="Fogle"
    >
      <span className="text-fogle-blue">F</span>
      <span className="text-fogle-red">o</span>
      <span className="text-fogle-yellow">g</span>
      <span className="text-fogle-blue">l</span>
      <span className="text-fogle-green">e</span>
    </span>
  );
}

export function FogleLogo({
  size = "lg",
  className,
}: {
  size?: Size;
  className?: string;
}) {
  return (
    <Link
      to="/"
      className={cn(
        "inline-flex items-center rounded-sm focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-accent",
        className,
      )}
      aria-label="Fogle — página inicial"
    >
      <FogleWordmark size={size} />
    </Link>
  );
}
