import { Fragment, type ReactNode } from "react";
import { cn } from "@/lib/utils";

function inline(text: string): ReactNode[] {
  const parts = text.split(/(`[^`]+`|\*\*[^*]+\*\*)/g);
  return parts.map((part, i) => {
    if (part.startsWith("`") && part.endsWith("`") && part.length >= 2) {
      return (
        <code
          key={i}
          className="rounded-xs bg-surface-2 px-1 py-0.5 font-mono text-sm text-fg"
        >
          {part.slice(1, -1)}
        </code>
      );
    }
    if (part.startsWith("**") && part.endsWith("**") && part.length >= 4) {
      return (
        <strong key={i} className="font-semibold text-fg">
          {part.slice(2, -2)}
        </strong>
      );
    }
    return <Fragment key={i}>{part}</Fragment>;
  });
}

export function MarkdownLite({
  text,
  className,
}: {
  text: string;
  className?: string;
}) {
  const blocks = text.replace(/\r\n/g, "\n").split(/\n{2,}/);

  return (
    <div className={cn("space-y-3 text-base leading-relaxed text-fg", className)}>
      {blocks.map((block, i) => {
        const lines = block.split("\n").map((l) => l.trimEnd());
        const heading = lines[0]?.match(/^(#{1,3})\s+(.+)$/);
        if (heading && lines.length === 1) {
          const Tag = heading[1].length === 1 ? "h3" : "h4";
          return (
            <Tag
              key={i}
              className="font-display text-lg font-semibold tracking-tight text-fg"
            >
              {inline(heading[2])}
            </Tag>
          );
        }

        const listItems = lines.filter((l) => /^[-*]\s+/.test(l) || /^\d+\.\s+/.test(l));
        if (listItems.length === lines.length && lines.length > 0) {
          const ordered = /^\d+\.\s+/.test(lines[0] ?? "");
          const List = ordered ? "ol" : "ul";
          return (
            <List
              key={i}
              className={cn(
                "space-y-1 pl-5 text-fg",
                ordered ? "list-decimal" : "list-disc",
              )}
            >
              {lines.map((line, j) => (
                <li key={j} className="pl-1">
                  {inline(line.replace(/^([-*]|\d+\.)\s+/, ""))}
                </li>
              ))}
            </List>
          );
        }

        return (
          <p key={i} className="whitespace-pre-wrap">
            {lines.map((line, j) => (
              <Fragment key={j}>
                {j > 0 ? <br /> : null}
                {inline(line)}
              </Fragment>
            ))}
          </p>
        );
      })}
    </div>
  );
}
