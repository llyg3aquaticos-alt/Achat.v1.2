import { useEffect, useId, useRef, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Clock, Mic, Search, X } from "lucide-react";
import { AchatMark } from "@/components/achat-mark";
import { clearRecents, getRecents, removeRecent, saveRecent } from "@/lib/recents";
import { pickLuckyQuery } from "@/lib/lucky";
import { cn } from "@/lib/utils";

type Variant = "hero" | "bar";

type Recog = {
  lang: string;
  interimResults: boolean;
  start: () => void;
  abort: () => void;
  onresult: ((event: { results: ArrayLike<ArrayLike<{ transcript?: string }>> }) => void) | null;
  onerror: (() => void) | null;
  onend: (() => void) | null;
};

function getSpeechCtor(): (new () => Recog) | null {
  if (typeof window === "undefined") return null;
  const w = window as unknown as {
    SpeechRecognition?: new () => Recog;
    webkitSpeechRecognition?: new () => Recog;
  };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

export function SearchBox({
  variant,
  initialQuery = "",
  autoFocus,
  showActions = false,
}: {
  variant: Variant;
  initialQuery?: string;
  autoFocus?: boolean;
  showActions?: boolean;
}) {
  const navigate = useNavigate();
  const inputId = useId();
  const rootRef = useRef<HTMLDivElement>(null);
  const onHeard = useRef<(text: string) => void>(() => {});
  const recRef = useRef<Recog | null>(null);
  const [q, setQ] = useState(initialQuery);
  const [focused, setFocused] = useState(false);
  const [recents, setRecents] = useState<string[]>([]);
  const [listening, setListening] = useState(false);
  const [canTalk, setCanTalk] = useState(false);

  useEffect(() => {
    setQ(initialQuery);
  }, [initialQuery]);

  useEffect(() => {
    setRecents(getRecents());
  }, [focused]);

  useEffect(() => {
    const Ctor = getSpeechCtor();
    if (!Ctor) return;
    const rec = new Ctor();
    rec.lang = "pt-BR";
    rec.interimResults = false;
    rec.onresult = (event) => {
      const text = event.results[0]?.[0]?.transcript?.trim() ?? "";
      if (text) onHeard.current(text);
      setListening(false);
    };
    rec.onerror = () => setListening(false);
    rec.onend = () => setListening(false);
    recRef.current = rec;
    setCanTalk(true);
    return () => rec.abort();
  }, []);

  function goSearch(value?: string) {
    const query = (value ?? q).trim();
    if (!query) return;
    saveRecent(query);
    setRecents(getRecents());
    setFocused(false);
    void navigate({ to: "/search", search: { q: query } });
  }

  function goAchat(value?: string) {
    const query = (value ?? q).trim();
    setFocused(false);
    void navigate({
      to: "/achat",
      search: query ? { q: query } : {},
    });
  }

  onHeard.current = (text) => {
    setQ(text);
    goSearch(text);
  };

  const showSuggest = focused && q.trim() === "" && recents.length > 0;

  function toggleMic() {
    const rec = recRef.current;
    if (!rec) return;
    if (listening) {
      rec.abort();
      setListening(false);
      return;
    }
    try {
      rec.start();
      setListening(true);
    } catch {
      setListening(false);
    }
  }

  return (
    <div ref={rootRef} className="w-full max-w-search">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          goSearch();
        }}
        className={cn(
          "relative flex items-center gap-2 rounded-pill border bg-bg px-4",
          variant === "hero" ? "h-12 shadow-search" : "h-11 border-border-strong",
          focused || showSuggest
            ? "border-transparent shadow-search-hover"
            : variant === "hero"
              ? "border-transparent hover:shadow-search-hover"
              : "hover:shadow-search",
          showSuggest && "rounded-b-none shadow-search-hover",
        )}
      >
        <Search className="size-4 shrink-0 text-subtle" strokeWidth={2} aria-hidden />
        <label htmlFor={inputId} className="sr-only">
          Pesquisar no Fogle
        </label>
        <input
          id={inputId}
          value={q}
          autoFocus={autoFocus}
          autoComplete="off"
          spellCheck={false}
          placeholder={
            variant === "hero" ? "Pesquise no Fogle ou pergunte ao Achat" : "Pesquisar no Fogle"
          }
          onChange={(e) => setQ(e.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={(e) => {
            if (rootRef.current?.contains(e.relatedTarget as Node)) return;
            setFocused(false);
          }}
          className="h-full min-w-0 flex-1 bg-transparent text-base text-fg outline-none placeholder:text-subtle"
        />
        {q ? (
          <button
            type="button"
            aria-label="Limpar"
            onClick={() => setQ("")}
            className="press grid size-9 place-items-center rounded-full text-muted hover:bg-surface"
          >
            <X className="size-4" />
          </button>
        ) : null}
        {canTalk ? (
          <button
            type="button"
            aria-label={listening ? "Parar ditado" : "Pesquisar por voz"}
            onClick={toggleMic}
            className={cn(
              "press grid size-9 place-items-center rounded-full text-accent hover:bg-accent-soft",
              listening && "bg-accent-soft",
            )}
          >
            <Mic className="size-4" />
          </button>
        ) : null}
        <button
          type="button"
          aria-label="Perguntar ao Achat"
          onClick={() => goAchat()}
          className="press grid size-9 place-items-center rounded-full text-accent hover:bg-accent-soft"
        >
          <AchatMark className="size-4" />
        </button>
      </form>

      {showSuggest ? (
        <ul className="relative z-20 overflow-hidden rounded-b-xl border border-transparent bg-bg py-2 shadow-search-hover">
          {recents.map((item) => (
            <li key={item} className="flex items-center">
              <button
                type="button"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => goSearch(item)}
                className="flex min-h-11 flex-1 items-center gap-3 px-4 text-left text-sm text-fg hover:bg-surface"
              >
                <Clock className="size-4 text-subtle" />
                <span className="truncate">{item}</span>
              </button>
              <button
                type="button"
                aria-label={`Remover ${item}`}
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => {
                  removeRecent(item);
                  setRecents(getRecents());
                }}
                className="mr-2 grid size-9 place-items-center rounded-full text-subtle hover:bg-surface hover:text-fg"
              >
                <X className="size-3.5" />
              </button>
            </li>
          ))}
          <li className="px-4 pt-1">
            <button
              type="button"
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => {
                clearRecents();
                setRecents([]);
              }}
              className="text-xs text-muted hover:text-fg"
            >
              Limpar histórico
            </button>
          </li>
        </ul>
      ) : null}

      {showActions ? (
        <div className="mt-7 flex flex-wrap items-center justify-center gap-3">
          <button type="button" className="fogle-btn press" onClick={() => goSearch()}>
            Pesquisa Fogle
          </button>
          <button type="button" className="fogle-btn fogle-btn-achat press" onClick={() => goAchat()}>
            <AchatMark className="size-3.5" />
            Achat
          </button>
          <button
            type="button"
            className="fogle-btn press"
            onClick={() =>
              void navigate({
                to: "/achat",
                search: { q: pickLuckyQuery(), lucky: "1" },
              })
            }
          >
            Estou com sorte
          </button>
        </div>
      ) : null}
    </div>
  );
}
