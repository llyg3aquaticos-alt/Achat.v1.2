import { useEffect, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { ChevronRight } from "lucide-react";
import { AchatMark } from "@/components/achat-mark";
import { MarkdownLite } from "@/components/markdown-lite";
import { fetchSearch } from "@/lib/achat-client";
import type { SearchPayload } from "@/lib/achat-types";
import { cn } from "@/lib/utils";

export function SearchResults({ query }: { query: string }) {
  const [data, setData] = useState<SearchPayload | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    let alive = true;
    setLoading(true);
    setError(null);
    void fetchSearch(query)
      .then((payload) => {
        if (!alive) return;
        setData(payload);
      })
      .catch((err: unknown) => {
        if (!alive) return;
        setError(err instanceof Error ? err.message : "Não foi possível pesquisar.");
      })
      .finally(() => {
        if (alive) setLoading(false);
      });
    return () => {
      alive = false;
    };
  }, [query]);

  return (
    <div className="mx-auto w-full max-w-results px-4 pb-16 pt-3">
      <div className="mb-5 flex gap-6 border-b border-border text-sm">
        <span className="relative -mb-px border-b-2 border-accent py-3 font-medium text-accent">
          Todas
        </span>
        <Link
          to="/achat"
          search={{ q: query }}
          className="relative -mb-px py-3 text-muted hover:text-fg"
        >
          Achat
        </Link>
      </div>

      <p className="mb-4 text-xs text-subtle">Resultados do Achat para “{query}”</p>

      {loading ? <ResultsSkeleton /> : null}
      {error ? (
        <div className="rounded-xl border border-border bg-bg p-5">
          <p className="text-danger">{error}</p>
          <button
            type="button"
            className="fogle-btn mt-4 press"
            onClick={() => {
              setLoading(true);
              setError(null);
              void fetchSearch(query)
                .then(setData)
                .catch((err: unknown) =>
                  setError(err instanceof Error ? err.message : "Não foi possível pesquisar."),
                )
                .finally(() => setLoading(false));
            }}
          >
            Tentar de novo
          </button>
        </div>
      ) : null}

      {data && !loading ? (
        <div className="space-y-8">
          <section className="rounded-xl border border-border bg-bg p-5">
            <div className="mb-3 flex items-center gap-2 text-sm font-medium text-accent">
              <AchatMark className="size-4" />
              Visão do Achat
            </div>
            <MarkdownLite text={data.overview} />
            <div className="mt-4">
              <Link
                to="/achat"
                search={{ q: query }}
                className="fogle-btn fogle-btn-achat press text-sm"
              >
                Continuar no Achat
              </Link>
            </div>
          </section>

          {data.cards.length > 0 ? (
            <section className="space-y-5">
              {data.cards.map((card) => (
                <article key={card.title}>
                  <p className="text-xs text-fogle-green">Tópico do Achat</p>
                  <h2 className="text-xl text-link hover:underline">
                    <Link to="/achat" search={{ q: card.title }}>
                      {card.title}
                    </Link>
                  </h2>
                  <p className="mt-1 text-base leading-relaxed text-fg">{card.snippet}</p>
                </article>
              ))}
            </section>
          ) : null}

          {data.related.length > 0 ? (
            <section>
              <h2 className="mb-2 text-base font-medium text-fg">As pessoas também perguntam</h2>
              <ul className="divide-y divide-border overflow-hidden rounded-lg border border-border">
                {data.related.map((item) => (
                  <li key={item}>
                    <button
                      type="button"
                      onClick={() => void navigate({ to: "/search", search: { q: item } })}
                      className={cn(
                        "flex min-h-12 w-full items-center justify-between gap-3 px-4 py-3 text-left text-sm text-fg hover:bg-surface",
                      )}
                    >
                      <span>{item}</span>
                      <ChevronRight className="size-4 shrink-0 text-subtle" />
                    </button>
                  </li>
                ))}
              </ul>
            </section>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}

function ResultsSkeleton() {
  return (
    <div className="space-y-6" aria-busy="true" aria-label="Carregando resultados">
      <div className="rounded-xl border border-border p-5">
        <div className="mb-3 h-4 w-32 rounded-sm shimmer" />
        <div className="space-y-2">
          <div className="h-4 w-full rounded-sm shimmer" />
          <div className="h-4 w-11/12 rounded-sm shimmer" />
          <div className="h-4 w-4/5 rounded-sm shimmer" />
        </div>
      </div>
      {[0, 1, 2].map((i) => (
        <div key={i} className="space-y-2">
          <div className="h-3 w-24 rounded-sm shimmer" />
          <div className="h-5 w-2/3 rounded-sm shimmer" />
          <div className="h-4 w-full rounded-sm shimmer" />
        </div>
      ))}
    </div>
  );
}
