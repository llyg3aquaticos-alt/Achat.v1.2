import { Link } from "@tanstack/react-router";

export function SiteFooter() {
  return (
    <footer className="mt-auto bg-surface text-sm text-muted">
      <div className="border-b border-border px-5 py-3">Brasil</div>
      <div className="flex flex-col gap-2 px-5 py-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap gap-x-6 gap-y-2">
          <Link to="/sobre" className="hover:underline">
            Sobre
          </Link>
          <Link to="/sobre" hash="achat" className="hover:underline">
            Achat
          </Link>
          <Link to="/sobre" hash="como" className="hover:underline">
            Como funciona
          </Link>
        </div>
        <div className="flex flex-wrap gap-x-6 gap-y-2">
          <Link to="/sobre" hash="privacidade" className="hover:underline">
            Privacidade
          </Link>
          <Link to="/sobre" hash="termos" className="hover:underline">
            Termos
          </Link>
        </div>
      </div>
    </footer>
  );
}
