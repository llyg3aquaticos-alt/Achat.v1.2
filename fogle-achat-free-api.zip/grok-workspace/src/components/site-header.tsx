import { Link } from "@tanstack/react-router";
import { AppsMenu, HeaderAvatar } from "@/components/apps-menu";
import { FogleLogo } from "@/components/fogle-logo";
import { SearchBox } from "@/components/search-box";
import { cn } from "@/lib/utils";

export function SiteHeader({
  variant,
  query = "",
}: {
  variant: "home" | "inner";
  query?: string;
}) {
  return (
    <header
      className={cn(
        "flex items-center gap-2 px-3 py-2 sm:gap-3 sm:px-4",
        variant === "inner" && "border-b border-border",
      )}
    >
      {variant === "inner" ? (
        <div className="shrink-0">
          <FogleLogo size="sm" />
        </div>
      ) : (
        <div className="flex-1" />
      )}

      {variant === "inner" ? (
        <div className="min-w-0 flex-1">
          <SearchBox variant="bar" initialQuery={query} />
        </div>
      ) : null}

      <nav className="ml-auto flex shrink-0 items-center gap-1 sm:gap-2">
        <Link
          to="/achat"
          className="hidden rounded-sm px-2 py-2 text-sm text-fg hover:underline sm:inline"
        >
          Achat
        </Link>
        <Link
          to="/sobre"
          className="hidden rounded-sm px-2 py-2 text-sm text-fg hover:underline md:inline"
        >
          Sobre
        </Link>
        <AppsMenu />
        <HeaderAvatar />
      </nav>
    </header>
  );
}
