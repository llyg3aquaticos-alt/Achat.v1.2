import type { SearchPayload } from "./achat-types";
import { runFogleSearch } from "./achat";

export type ClientMessage = { role: "user" | "assistant"; content: string };

const searchCache = new Map<string, SearchPayload>();
const searchInflight = new Map<string, Promise<SearchPayload>>();

export async function fetchSearch(query: string): Promise<SearchPayload> {
  const key = query.trim();
  const cached = searchCache.get(key);
  if (cached) return cached;
  const pending = searchInflight.get(key);
  if (pending) return pending;

  const job = (async () => {
    const result = await runFogleSearch({ data: { query: key } });
    if (!result.ok) throw new Error(result.error);
    searchCache.set(key, result.data);
    return result.data;
  })();

  searchInflight.set(key, job);
  try {
    return await job;
  } finally {
    searchInflight.delete(key);
  }
}

export async function streamAchat(
  messages: ClientMessage[],
  onDelta: (chunk: string) => void,
  signal?: AbortSignal,
): Promise<void> {
  const res = await fetch("/api/achat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ messages }),
    signal,
  });

  if (!res.ok) {
    let message = "Achat indisponível.";
    try {
      const body = (await res.json()) as { error?: string };
      if (body.error) message = body.error;
    } catch {
      // keep default
    }
    throw new Error(message);
  }

  if (!res.body) throw new Error("Achat indisponível.");

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed.startsWith("data:")) continue;
      const data = trimmed.slice(5).trim();
      if (data === "[DONE]") return;
      try {
        const json = JSON.parse(data) as { delta?: string };
        if (json.delta) onDelta(json.delta);
      } catch {
        // ignore keep-alives
      }
    }
  }
}
