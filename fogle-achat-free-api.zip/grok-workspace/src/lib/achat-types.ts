export type ChatRole = "system" | "user" | "assistant";
export type ChatMessage = { role: ChatRole; content: string };

export type SearchCard = { title: string; snippet: string };
export type SearchPayload = {
  overview: string;
  cards: SearchCard[];
  related: string[];
};
