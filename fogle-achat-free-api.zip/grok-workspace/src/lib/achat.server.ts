// Achat agora usa Groq (API gratuita, sem créditos pagos)
// Crie uma chave grátis em: https://console.groq.com/keys
// Defina a variável de ambiente: GROQ_API_KEY

const MODEL = "llama-3.3-70b-versatile";
const MAX_OUTPUT = 900;
const MAX_INPUT = 2000;
const WINDOW_MS = 10 * 60 * 1000;
const MAX_HITS = 40;

const hits = new Map<string, { n: number; t: number }>();

export type { ChatMessage, ChatRole, SearchCard, SearchPayload } from "./achat-types";
import type { ChatMessage, SearchCard, SearchPayload } from "./achat-types";

export function allowRequest(ip: string): boolean {
  const now = Date.now();
  const rec = hits.get(ip);
  if (!rec || now - rec.t > WINDOW_MS) {
    hits.set(ip, { n: 1, t: now });
    return true;
  }
  if (rec.n >= MAX_HITS) return false;
  rec.n += 1;
  return true;
}

export function clientIp(request: Request): string {
  const forwarded = request.headers.get("x-forwarded-for");
  return forwarded?.split(",")[0]?.trim() || "local";
}

function apiKey(): string | null {
  // Prioridade: GROQ_API_KEY (grátis). Fallback para XAI se existir.
  const key =
    process.env.GROQ_API_KEY?.trim() ||
    process.env.XAI_API_KEY?.trim() ||
    null;
  return key || null;
}

const ACHAT_SYSTEM = `Você é o Achat, a inteligência artificial do Fogle — um buscador brasileiro.
Você vive direto no Fogle: responde na hora, com clareza e sem enrolação.
Fale sempre em português do Brasil, tom direto, amigável e inteligente.
Quando não souber, diga. Não invente fontes, citações ou URLs.
Use markdown simples: títulos curtos, listas, negrito. Sem tabelas enormes.`;

const SEARCH_SYSTEM = `Você é o Achat no Fogle, gerando uma visão de pesquisa em português do Brasil.
Estrutura OBRIGATÓRIA da resposta, sem texto fora dela:

VISÃO
(2 a 5 parágrafos ou uma lista útil sobre a consulta)

TÓPICOS
- Título do tópico | duas ou três frases
(4 a 6 linhas nesse formato)

RELACIONADAS
- pergunta 1
- pergunta 2
- pergunta 3
- pergunta 4

Regras: não invente URLs; seja direto; se a consulta for ambígua, cubra as leituras mais comuns.`;

function clip(text: string, max = MAX_INPUT): string {
  const t = text.trim();
  return t.length > max ? t.slice(0, max) : t;
}

function trimHistory(messages: ChatMessage[]): ChatMessage[] {
  const cleaned = messages
    .filter((m) => m.role === "user" || m.role === "assistant")
    .map((m) => ({ role: m.role, content: clip(m.content) }));
  return cleaned.slice(-8);
}

async function errorMessage(res: Response): Promise<string> {
  let body = "";
  try {
    body = await res.text();
  } catch {
    body = "";
  }
  const lower = body.toLowerCase();
  if (res.status === 429 || lower.includes("rate")) {
    return "Muitas perguntas em pouco tempo. Espere um minuto e tente de novo.";
  }
  if (res.status === 401 || lower.includes("invalid") || lower.includes("api key")) {
    return "Chave da API inválida ou ausente. Configure GROQ_API_KEY.";
  }
  if (res.status === 403 || lower.includes("spending-limit") || lower.includes("credits")) {
    return "Limite da API atingido. Tente de novo mais tarde.";
  }
  return "O Achat não conseguiu responder agora. Tente de novo.";
}

async function llmChat(body: Record<string, unknown>): Promise<Response> {
  const key = apiKey();
  if (!key) {
    return new Response(JSON.stringify({ error: "Achat indisponível neste ambiente. Configure GROQ_API_KEY." }), {
      status: 503,
      headers: { "Content-Type": "application/json" },
    });
  }

  // Usa Groq se a chave for GROQ, senão tenta xAI (compatível)
  const isGroq = !!process.env.GROQ_API_KEY?.trim();
  const baseUrl = isGroq
    ? "https://api.groq.com/openai/v1/chat/completions"
    : "https://api.x.ai/v1/chat/completions";
  const model = isGroq ? MODEL : "grok-4.5";

  return fetch(baseUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${key}`,
    },
    body: JSON.stringify({ model, ...body }),
  });
}

export async function completeAchat(
  messages: ChatMessage[],
  system = ACHAT_SYSTEM,
): Promise<{ ok: true; text: string } | { ok: false; error: string; status: number }> {
  const res = await llmChat({
    max_tokens: MAX_OUTPUT,
    temperature: 0.7,
    messages: [{ role: "system", content: system }, ...trimHistory(messages)],
  });
  if (!res.ok) {
    return { ok: false, error: await errorMessage(res), status: res.status };
  }
  const json = (await res.json()) as {
    choices?: { message?: { content?: string } }[];
  };
  return { ok: true, text: json.choices?.[0]?.message?.content?.trim() || "" };
}

export async function streamAchatResponse(
  messages: ChatMessage[],
  ip: string,
): Promise<Response> {
  if (!allowRequest(ip)) {
    return Response.json(
      { error: "Muitas perguntas em pouco tempo. Espere um minuto e tente de novo." },
      { status: 429 },
    );
  }
  if (!apiKey()) {
    return Response.json(
      { error: "Achat indisponível. Configure a variável GROQ_API_KEY (grátis em console.groq.com)." },
      { status: 503 },
    );
  }

  const res = await llmChat({
    stream: true,
    max_tokens: MAX_OUTPUT,
    temperature: 0.7,
    messages: [{ role: "system", content: ACHAT_SYSTEM }, ...trimHistory(messages)],
  });

  if (!res.ok || !res.body) {
    if (!res.ok) {
      return Response.json({ error: await errorMessage(res) }, { status: res.status });
    }
    const fallback = await completeAchat(messages);
    if (!fallback.ok) {
      return Response.json({ error: fallback.error }, { status: fallback.status });
    }
    const encoder = new TextEncoder();
    const stream = new ReadableStream({
      start(controller) {
        controller.enqueue(encoder.encode(`data: ${JSON.stringify({ delta: fallback.text })}\n\n`));
        controller.enqueue(encoder.encode("data: [DONE]\n\n"));
        controller.close();
      },
    });
    return new Response(stream, {
      headers: {
        "Content-Type": "text/event-stream; charset=utf-8",
        "Cache-Control": "no-store",
      },
    });
  }

  const encoder = new TextEncoder();
  const decoder = new TextDecoder();
  const reader = res.body.getReader();

  const stream = new ReadableStream({
    async start(controller) {
      let buffer = "";
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() ?? "";
          for (const line of lines) {
            const trimmed = line.trim();
            if (!trimmed.startsWith("data:")) continue;
            const data = trimmed.slice(5).trim();
            if (data === "[DONE]") {
              controller.enqueue(encoder.encode("data: [DONE]\n\n"));
              controller.close();
              return;
            }
            try {
              const json = JSON.parse(data) as {
                choices?: { delta?: { content?: string } }[];
              };
              const delta = json.choices?.[0]?.delta?.content;
              if (delta) {
                controller.enqueue(encoder.encode(`data: ${JSON.stringify({ delta })}\n\n`));
              }
            } catch {
              // ignore malformed chunks
            }
          }
        }
        controller.enqueue(encoder.encode("data: [DONE]\n\n"));
        controller.close();
      } catch (err) {
        controller.error(err);
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-store",
    },
  });
}

function section(text: string, name: string): string {
  const re = new RegExp(
    `${name}\\s*\\n([\\s\\S]*?)(?=\\n(?:VISÃO|TÓPICOS|TOPICOS|RELACIONADAS)\\s*(?:\\n|$)|$)`,
    "i",
  );
  const m = text.match(re);
  return m?.[1]?.trim() ?? "";
}

function parseSearch(text: string, query: string): SearchPayload {
  const visao = section(text, "VISÃO") || section(text, "VISAO");
  const topicos = section(text, "TÓPICOS") || section(text, "TOPICOS");
  const relatedBlock = section(text, "RELACIONADAS");

  const cards: SearchCard[] = [];
  for (const rawLine of topicos.split("\n")) {
    const line = rawLine.replace(/^[-*]\s+/, "").trim();
    if (!line) continue;
    const [title, ...rest] = line.split("|");
    const snippet = rest.join("|").trim();
    if (title && snippet) {
      cards.push({ title: title.trim(), snippet });
    }
  }

  const related = relatedBlock
    .split("\n")
    .map((l) => l.replace(/^[-*]\s+/, "").trim())
    .filter(Boolean)
    .slice(0, 6);

  return {
    overview: visao || text.trim() || `Não consegui montar uma visão para “${query}”. Tente de outro jeito.`,
    cards: cards.slice(0, 6),
    related,
  };
}

export async function searchAchat(
  query: string,
  ip: string,
): Promise<{ ok: true; data: SearchPayload } | { ok: false; error: string }> {
  if (!allowRequest(ip)) {
    return { ok: false, error: "Muitas pesquisas em pouco tempo. Espere um minuto e tente de novo." };
  }
  if (!apiKey()) {
    return { ok: false, error: "Achat indisponível. Configure GROQ_API_KEY (grátis)." };
  }
  const q = clip(query, 400);
  if (!q) return { ok: false, error: "Digite o que você quer pesquisar." };

  const result = await completeAchat([{ role: "user", content: q }], SEARCH_SYSTEM);
  if (!result.ok) return { ok: false, error: result.error };
  return { ok: true, data: parseSearch(result.text, q) };
}
