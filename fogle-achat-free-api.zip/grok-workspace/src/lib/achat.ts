import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const SearchInput = z.object({
  query: z.string().trim().min(1).max(400),
});

export const runFogleSearch = createServerFn({ method: "POST" })
  .validator(SearchInput)
  .handler(async ({ data }) => {
    const { getRequest } = await import("@tanstack/react-start/server");
    const { searchAchat, clientIp } = await import("./achat.server");
    const ip = clientIp(getRequest());
    return searchAchat(data.query, ip);
  });
