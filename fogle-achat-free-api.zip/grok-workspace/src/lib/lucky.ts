export const LUCKY_QUERIES = [
  "Por que o céu é azul?",
  "Como fazer o pão de queijo perfeito?",
  "Me explique a Copa do Mundo em 8 frases",
  "O que tem dentro de um buraco negro?",
  "Qual o maior animal que já existiu?",
  "Por que o feijão com arroz combina tanto?",
  "O que é um quasar, sem enrolação",
  "Traduza a palavra saudade para alguém que nunca sentiu",
  "Quem inventou o churrasco?",
  "Me conte a história do Fogle com carinho",
  "Como funciona a inteligência artificial, simples",
  "Qual a capital mais ao sul do mundo?",
] as const;

export function pickLuckyQuery(): string {
  const i = Math.floor(Math.random() * LUCKY_QUERIES.length);
  return LUCKY_QUERIES[i] ?? LUCKY_QUERIES[0];
}
