const KEY = "fogle-recents";
const LIMIT = 8;

export function getRecents(): string[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((item): item is string => typeof item === "string").slice(0, LIMIT);
  } catch {
    return [];
  }
}

export function saveRecent(query: string) {
  const q = query.trim();
  if (!q) return;
  const next = [q, ...getRecents().filter((item) => item.toLowerCase() !== q.toLowerCase())].slice(
    0,
    LIMIT,
  );
  window.localStorage.setItem(KEY, JSON.stringify(next));
}

export function removeRecent(query: string) {
  const next = getRecents().filter((item) => item !== query);
  window.localStorage.setItem(KEY, JSON.stringify(next));
}

export function clearRecents() {
  window.localStorage.removeItem(KEY);
}
