import { createFileRoute } from "@tanstack/react-router";
import { AchatChat } from "@/components/achat-chat";
import { SiteHeader } from "@/components/site-header";

type AchatSearch = {
  q?: string;
  lucky?: string;
};

export const Route = createFileRoute("/achat")({
  validateSearch: (search: Record<string, unknown>): AchatSearch => {
    const next: AchatSearch = {};
    if (typeof search.q === "string" && search.q.length > 0) next.q = search.q;
    if (typeof search.lucky === "string" && search.lucky.length > 0) next.lucky = search.lucky;
    return next;
  },
  head: () => ({
    meta: [{ title: "Achat — Fogle" }],
  }),
  component: AchatPage,
});

function AchatPage() {
  const { q, lucky } = Route.useSearch();

  return (
    <div className="flex h-dvh flex-col bg-bg">
      <SiteHeader variant="inner" query={q ?? ""} />
      <AchatChat initialQuery={q ?? ""} lucky={lucky === "1"} />
    </div>
  );
}
