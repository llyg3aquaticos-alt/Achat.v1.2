import { createFileRoute } from "@tanstack/react-router";
import type { ChatMessage } from "@/lib/achat-types";

type Body = {
  messages?: { role?: unknown; content?: unknown }[];
};

export const Route = createFileRoute("/api/achat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { clientIp, streamAchatResponse } = await import("@/lib/achat.server");
        let body: Body;
        try {
          body = (await request.json()) as Body;
        } catch {
          return Response.json({ error: "Pedido inválido." }, { status: 400 });
        }
        const messages: ChatMessage[] = (body.messages ?? [])
          .filter(
            (m): m is { role: "user" | "assistant"; content: string } =>
              (m.role === "user" || m.role === "assistant") &&
              typeof m.content === "string" &&
              m.content.trim().length > 0,
          )
          .map((m) => ({ role: m.role, content: m.content.trim() }))
          .slice(-8);

        if (messages.length === 0) {
          return Response.json({ error: "Escreva uma pergunta para o Achat." }, { status: 400 });
        }

        return streamAchatResponse(messages, clientIp(request));
      },
    },
  },
});
