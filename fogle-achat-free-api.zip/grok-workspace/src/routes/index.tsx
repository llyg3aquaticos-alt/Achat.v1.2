import { createFileRoute, Link } from "@tanstack/react-router";
import { FogleWordmark } from "@/components/fogle-logo";
import { SearchBox } from "@/components/search-box";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";

export const Route = createFileRoute("/")({
  component: Home,
  head: () => ({
    meta: [{ title: "Fogle" }],
  }),
});

const CHIPS = [
  "O que é o Achat",
  "Receitas rápidas",
  "História do Brasil",
  "Como funciona a IA",
];

function Home() {
  return (
    <div className="flex min-h-dvh flex-col overflow-x-hidden bg-bg">
      <SiteHeader variant="home" />
      <main className="flex flex-1 flex-col items-center px-4 pt-hero sm:pt-hero-lg">
        <div className="rise-1">
          <h1>
            <FogleWordmark size="lg" />
          </h1>
        </div>
        <p className="rise-2 mt-3 text-sm text-muted">O Achat, direto no Fogle</p>
        <div className="rise-3 mt-7 flex w-full justify-center">
          <SearchBox variant="hero" autoFocus showActions />
        </div>
        <ul className="rise-4 mt-8 flex max-w-search flex-wrap justify-center gap-2">
          {CHIPS.map((chip) => (
            <li key={chip}>
              <Link
                to="/search"
                search={{ q: chip }}
                className="inline-flex min-h-9 items-center rounded-pill bg-surface px-3 text-sm text-muted hover:bg-surface-2 hover:text-fg"
              >
                {chip}
              </Link>
            </li>
          ))}
        </ul>
      </main>
      <SiteFooter />
    </div>
  );
}
