import { createFileRoute } from "@tanstack/react-router";
import { SearchResults } from "@/components/search-results";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";

export const Route = createFileRoute("/search")({
  validateSearch: (search: Record<string, unknown>) => ({
    q: typeof search.q === "string" ? search.q : "",
  }),
  head: () => ({
    meta: [{ title: "Pesquisa Fogle" }],
  }),
  component: SearchPage,
});

function SearchPage() {
  const { q } = Route.useSearch();

  return (
    <div className="flex min-h-dvh flex-col bg-bg">
      <SiteHeader variant="inner" query={q} />
      <main className="flex-1">
        {q.trim() ? (
          <SearchResults query={q.trim()} />
        ) : (
          <p className="mx-auto max-w-results px-4 py-16 text-muted">
            Digite algo na busca para o Achat pesquisar.
          </p>
        )}
      </main>
      <SiteFooter />
    </div>
  );
}
