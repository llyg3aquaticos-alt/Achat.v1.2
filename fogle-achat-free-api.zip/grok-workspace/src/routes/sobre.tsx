import { createFileRoute } from "@tanstack/react-router";
import { FogleLogo } from "@/components/fogle-logo";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";

export const Route = createFileRoute("/sobre")({
  component: AboutPage,
  head: () => ({
    meta: [{ title: "Sobre o Fogle" }],
  }),
});

function AboutPage() {
  return (
    <div className="flex min-h-dvh flex-col bg-bg">
      <SiteHeader variant="inner" />
      <main className="mx-auto w-full max-w-results flex-1 px-4 py-10">
        <FogleLogo size="md" />
        <h1 className="mt-6 font-display text-3xl font-semibold tracking-tight">Sobre o Fogle</h1>
        <p className="mt-3 text-muted">
          O Fogle é um buscador com uma inteligência no centro: o Achat. Você pesquisa como
          sempre — e pergunta quando quiser ir direto ao ponto.
        </p>

        <section id="achat" className="mt-10 scroll-mt-8">
          <h2 className="font-display text-xl font-semibold">Achat</h2>
          <p className="mt-2 text-fg">
            O Achat é a IA do Fogle. Ele responde em português do Brasil, monta visões de
            pesquisa e conversa sem mudar de site. Direto no Fogle, sem enrolação.
          </p>
        </section>

        <section id="como" className="mt-10 scroll-mt-8">
          <h2 className="font-display text-xl font-semibold">Como funciona</h2>
          <p className="mt-2 text-fg">
            A caixa de pesquisa envia sua pergunta ao Achat. Em “Pesquisa Fogle”, ele devolve
            uma visão + tópicos. Em “Achat”, vocês conversam. O microfone dita em português.
            “Estou com sorte” escolhe uma pergunta inesperada.
          </p>
        </section>

        <section id="privacidade" className="mt-10 scroll-mt-8">
          <h2 className="font-display text-xl font-semibold">Privacidade</h2>
          <p className="mt-2 text-fg">
            O Fogle guarda só o histórico de buscas neste aparelho (você pode limpar). As
            conversas com o Achat passam pelo servidor para gerar a resposta e não ficam numa
            conta. Não peça senhas, dados bancários ou informações sensíveis ao Achat.
          </p>
        </section>

        <section id="termos" className="mt-10 scroll-mt-8">
          <h2 className="font-display text-xl font-semibold">Termos</h2>
          <p className="mt-2 text-fg">
            O Achat pode errar. Use o Fogle como ponto de partida, não como fonte única para
            decisões médicas, jurídicas ou financeiras. Ao usar o serviço, você concorda em
            não tentar sobrecarregar a IA nem usá-la para atividade ilegal.
          </p>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}
